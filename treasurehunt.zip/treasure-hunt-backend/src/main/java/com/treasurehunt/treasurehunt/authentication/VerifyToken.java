package com.treasurehunt.treasurehunt.authentication;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;

import java.security.Key;

public class VerifyToken {
    public string verifyToken(string) {
    // On subsequent requests, the token is decoded with the same private key and if valid the request is processed.
        Jws<Claims> result = Jwts.parser()
                .requireAudience("video demo")
                .setAllowedClockSkewSeconds(62)
                .setSigningKey(Key.hmacShaKeyFor(secret))
                .parseClaimJwt(jwt));

    }

}
