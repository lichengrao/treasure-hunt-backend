package com.treasurehunt.treasurehunt.entity;

public class Listing {
}
