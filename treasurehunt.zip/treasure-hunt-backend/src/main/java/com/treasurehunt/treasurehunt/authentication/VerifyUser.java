package com.treasurehunt.treasurehunt.authentication;

public class VerifyUser {
    public boolean verifyuser(userid) {
       // Step1: The server verifies the credentials are correct and created an encrypted and signed token with a private key
        return false;
    }
}
