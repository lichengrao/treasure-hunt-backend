package com.treasurehunt.treasurehunt.authentication;

import io.jsonwebtoken.Jwts;

import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Random;

public class GenerateToken {
    public String sendToken(userid) {

        String jwt = Jwts.builder()
                .setSubject("Joe")
                .setAudience("video demo")
                .claim("1d20", new Random().nextInt(20) + 1)
                .setIssuedAt(Date.from(now.plus(1, ChronoUnit.MINUTES)))
                .compact();

        System.out.println(jwt);
    }
}
