package com.treasurehunt.treasurehunt.authentication;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
//import io.jsonwebtoken.impl.crypto.MacProvider;
import java.security.Key;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Date;
import java.util.Random;


public class Authentication {
//    1.A user enters their login credentials (=username + password).
//    2.The server verifies the credentials are correct and created an encrypted and signed token with
//    a private key ( { username: “abcd”, exp: “2021/1/1/10:00” }, private key => token).
//    3.Client-side stores the token returned from the server.传token回前端
//    4.On subsequent requests, the token is decoded with the same private key and if valid the request is processed.
//    是我们写的，并能分辨具体是谁
//    5.Once a user logs out, the token is destroyed client-side, no interaction with the server is necessary.

    // We need a signing key, so we'll create one just for this example. Usually
    // the key would be read from your application configuration instead.
    // Key key = MacProvider.generateKey();
    // String jwtString = Jwts.builder().setSubject("Joe").signWith(SignatureAlgorithm.HS512, key).compact();

    public static void  main(String[] args) {
        Instant now = Instant.now();
        byte[] secret = Base64.getDecoder().decode("");

        // Generate a JSON Web Token containing the Subject Joe signed with key
        String jwt = Jwts.builder()
                .setSubject("Joe")
                .setAudience("video demo")
                .claim("1d20", new Random().nextInt(20) + 1)
                .setIssuedAt(Date.from(now.plus(1, ChronoUnit.MINUTES)))
                .compact();

        System.out.println(jwt);

        // send to front end ...
        // To determine which key was used to sign the token
        Jws<Claims> result = Jwts.parser()
                .requireAudience("video demo")
                .setAllowedClockSkewSeconds(62)
                .setSigningKey(Key.hmacShaKeyFor(secret))
                .parseClaimJwt(jwt));



        System.out.println(result);
        System.out.println("1d20: " + result.getBody().get("1d20: ", Integer.class));



    }

}
